from distutils.core import setup

setup(
    name         ='pyhyperworks',
    version      ='1.0.0',
    py_modules   =['pyhyperworks'],
    author       ='xinxing.zhang',
    author_email ='zxx4477@126.com',
    description  ='Tools for Altiar Hyperworks App',
    )
